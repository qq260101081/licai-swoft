<?php
namespace App\Exception;

/**
 * Class ApiException
 *
 * @since 2.0
 */
class ApiException extends \Exception
{

}
