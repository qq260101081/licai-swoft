<?php declare(strict_types=1);


namespace App\Aspect;

/**
 * Class AnnotationAspect
 *
 * @since 2.0
 */
class AnnotationAspect
{

}