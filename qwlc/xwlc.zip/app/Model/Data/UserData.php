<?php declare(strict_types=1);


namespace App\Model\Data;


class UserData
{

}